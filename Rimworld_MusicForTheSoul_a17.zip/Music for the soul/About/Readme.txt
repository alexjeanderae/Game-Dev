New Joy Source: Play Music
aka: Music for the Soul

Mod for Rimworld

Steam ID: 1122076317
	
	
	Hi there!
	
I have developped -then have been using privately- this mod for my own games. Decided to share it with the community. :)
Having like 30+ mods installed, I noticed no conflict and believe it should work with other mods that tweak joy or music. If you see an issue, please let me know I ll look into it. 
	
	Basically this is a simple mod that serves a few purposes:
a- Add a "humming" joysource to the early game of the -crowded- meditative type. The source of joy is basically to sing in a private room. Only requires breathing, can be done in bed by patients. Small artistic skill Xp gain.
b- "Straight piano" is a joy furniture to build. It trains Artistic and gives social joy. It requires quite some material. Needs seating to use. 
c- "Karaoke Machine" is a joy furniture to research (Tube Television) then build. It trains social and gives same type of joy as watching TV. It uses 250 Watts (50 more than the tube television). Trains social and higher chances of colonists interactions.

	
	Game balance and some notes
- Generally I made sure the Xp gain as well as other parameters where in line with RimWorld vanilla. Horseshoe pin and billard being the joy source I used the parameters from when adding the music item.
- Karaoke machine deserves a few extra notes. It carries a negative cleanliness in the room the machine gets installed and requires manipulation. Therefore not suitable for hospital. Also it might quickly become one of your pawns favorite joy activity. If you prefer a raise to Artistic instead of Social. Feel free to change the code. Is  litteraly changing one word in M4_Jobs_Joy.xml.
- The mods files all start with M4_ to insure compatibility with other mods. Avoiding overwriting or sharing data.
- Small visual bug, you can sit behind the piano as well as in front. Consider that is a feature, doing maintenance on the cords, or listening to someone else playing!
- I understand that pianoes are mostly made of wood and then some steel. I however prefer to have them mostly of "metallic type" as per RimWorlds game mechanics. By doing so, it has a better effect on room impressiveness. Gold pianoes are now a thing! Futuristic craftmanship here we come!
	
In my mind this a very balanced addition to the game. Using this mod, will make your large recreation room less empty. A 12x12 vanilla recreation room with a billiard, a chess board, a pin and a megascreen does not feel "confy". Also it makes researching Tube Television more desireable as with this mod you have a second joy source attached to the tech. 


	In the pipe:
	- More languages: French, Russian, German, Ukrainian - if you want to give a hand and add more languages please contact me. 
	- I dont plan to add more music instruments. However, if anyone has a cool sprite for a grand piano and feels like sharing, I ll add it to the mod. Also if some tribal enthousiast has a cool sprite for a tribal drum, I could add it to the mod.
	- If 5k+ subs, I can consider to add sounds. Adding sounds is probably 2-3x more effort that was already done. I would need to make custom sounds from scratch then arcane coding (any sounds are hard to include to RW unfortunately).
	- Finally if anyone more skilled in graphics want to improve my sprites, I am also a taker. :)


	Last words:
	There are at least two great mods out there that expend on training and joy - check  "Additional Joy Objects" of cuproPanda and "Misc. Training" of Haplo_X1.  I use them both in most of my games. 
	Also, thanks to Eman On for his "RimWorld Modding Tutorial - Adding Custom Animals" on youtube that gave me the impulse to try this. This guy deserves more credit, please check his channel out.
